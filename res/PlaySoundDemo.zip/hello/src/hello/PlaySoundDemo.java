package hello;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;



public class PlaySoundDemo{
    public static void main(String[] args) {
        System.out.println("Hello");
        
     
        	 playSound();
     
    }

	private static void playSound() {  
		
		try { 
			 
		
			// Change to 60 for second version 
			// remember to change PlaySoundDemmo to "this" if this is not static class  
        AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(PlaySoundDemo.class.getClassLoader().getResource("StarWars3.wav"));
       // AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(this.class.getClassLoader().getResource("StarWars3.wav"));
        
        Clip clip = AudioSystem.getClip();
        clip.open(audioInputStream);
        clip.start();
       
        while (clip.getMicrosecondLength()!= clip.getMicrosecondPosition())
        		{
        	  //wait for clip to be played 
        		}
         System.out.println("Song ended ");
       
        // If you want the sound to loop infinitely, then put: clip.loop(Clip.LOOP_CONTINUOUSLY); 
        // If you want to stop the sound, then use clip.stop();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
		
	}
}